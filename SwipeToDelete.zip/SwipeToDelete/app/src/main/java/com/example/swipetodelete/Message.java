package com.example.swipetodelete;

public class Message {
    String messages;

    public Message(String messages) {
        this.messages = messages;
    }

    public String getMessages() {
        return messages;
    }

    public void setMessages(String messages) {
        this.messages = messages;
    }
}
